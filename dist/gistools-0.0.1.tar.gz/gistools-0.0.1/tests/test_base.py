from project_name.base import NAME


def test_base():
    assert NAME == "project_name"
